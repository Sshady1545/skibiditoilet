Eyes rig 3.0 by McHorse

Hello there! This is the third iteration of eyes rig for Blockbuster. To use this 
rig, it's recommended to use Blockbuster 2.1+, or at least Blockbuster 1.6.1.

Crediting the model is optional.

Tutorial link: https://youtu.be/vFhErlhTrMA