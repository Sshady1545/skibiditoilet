//The base model was created by Centryfuga

//I just modified the model and created the animations